<?php
include_once "connect_super.php"; // Ensure this file establishes a PDO connection and assigns it to $bdd
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Voitures</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/Supercar1.css">
</head>
<body>
    <nav class="navbar navbar-light navbar-expand-md sticky-top navbar-shrink py-3" id="mainNav">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center"><strong>Supercar</strong></a>
            <ul class="navbar-nav mx-auto">
                <li class="nav-item"><a class="nav-link active" href="voitures.php">Voitures</a></li>
            </ul>
        </div>
    </nav>
    <main>
        <h2>Liste des Voitures</h2>
    </main>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/vanilla-zoom.js"></script>
    <script src="assets/js/theme.js"></script>
</body>
</html>