<?php
session_start();
$bdd = new PDO('mysql:host=localhost;dbname=abaidine_supercar;charset=utf8', 'root', '');

// Function to fetch car information
function getCarInfo($bdd) {
    $query = $bdd->query('SELECT * FROM voiture'); // Assuming 'voiture' is the table name
    return $query->fetchAll(PDO::FETCH_ASSOC);
}

// Function to update car information
function updateCarInfo($bdd, $id, $imagePath, $voitureName, $prix) {
    $updateCar = $bdd->prepare('UPDATE voiture SET image_path = :image_path, voiture_name = :voiture_name, prix = :prix WHERE id = :id');
    $updateCar->execute(array(
        ':image_path' => $imagePath,
        ':voiture_name' => $voitureName,
        ':prix' => $prix,
        ':id' => $id
    ));
}

// Function to delete car information
function deleteCarInfo($bdd, $id) {
    $deleteCar = $bdd->prepare('DELETE FROM voiture WHERE id = :id');
    $deleteCar->execute(array(':id' => $id));
}

// Function to add a new car
function addCarInfo($bdd, $voitureName, $imagePath, $prix) {
    $stmt = $bdd->prepare("INSERT INTO voiture (voiture_name, image_path, prix) VALUES (:voiture_name, :image_path, :prix)");
    $stmt->execute(array(
        ':voiture_name' => $voitureName,
        ':image_path' => $imagePath,
        ':prix' => $prix
    ));
}

// Handle form submission for adding a new car
if (isset($_POST['submit'])) {
    // Define variables to avoid undefined index warnings
    $voiture_name = '';
    $prix = '';
    $image_tmp = '';
    $image_path = '';

    $upload_dir = 'uploads/';
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    // Check if the required fields are set
    if (!empty($_POST['voiture_name']) && !empty($_POST['prix']) && isset($_FILES['image'])) {
        $voiture_name = $_POST['voiture_name'];
        $prix = $_POST['prix'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $image_path = $upload_dir . basename($_FILES['image']['name']);
        $target_file = $image_path;
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if image file is a actual image or fake image
        $check = getimagesize($image_tmp);
        if ($check === false) {
            echo "Le fichier n'est pas une image.";
            $uploadOk = 0;
        }

        // Check file size
        if ($_FILES["image"]["size"] > 500000) {
            echo "Désolé, votre fichier est trop grand.";
            $uploadOk = 0;
        }

        // Allow certain file formats
        if (!in_array($imageFileType, ['jpg', 'png', 'jpeg', 'gif'])) {
            echo "Désolé, seuls les fichiers JPG, JPEG, PNG et GIF sont autorisés.";
            $uploadOk = 0;
        }

        if ($uploadOk == 0) {
            echo "Erreur, veuillez réessayer.";
        } else {
            if (move_uploaded_file($image_tmp, $target_file)) {
                addCarInfo($bdd, $voiture_name, $image_path, $prix);
                echo "Nouvelle voiture enregistrée !";
            } else {
                echo "Erreur lors du téléchargement de l'image, veuillez réessayer.";
            }
        }
    } else {
        echo "Veuillez remplir tous les champs requis.";
    }
}

// Handle form submission for updating car info
if (isset($_POST['update'])) {
    if (!empty($_POST['car_id']) && !empty($_POST['image_path']) && !empty($_POST['voiture_name']) && !empty($_POST['prix'])) {
        $car_id = $_POST['car_id'];
        $image_path = $_POST['image_path'];
        $voiture_name = $_POST['voiture_name'];
        $prix = $_POST['prix'];
        updateCarInfo($bdd, $car_id, $image_path, $voiture_name, $prix);
        echo "Les informations de la voiture ont été mises à jour.";
    } else {
        echo "Veuillez remplir tous les champs.";
    }
}

// Handle form submission for deleting car info
if (isset($_POST['delete'])) {
    if (!empty($_POST['car_id'])) {
        $car_id = $_POST['car_id'];
        deleteCarInfo($bdd, $car_id);
        echo "La voiture a été supprimée.";
    } else {
        echo "Veuillez sélectionner une voiture à supprimer.";
    }
}

// récupère car information
$cars = getCarInfo($bdd);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier les informations des voitures</title>
</head>
<body>
<h1>Ajouter une voiture</h1>

<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" enctype="multipart/form-data">
    <input type="text" name="voiture_name" placeholder="Saisissez le nom" required>
    <input type="text" name="prix" placeholder="Saisissez le prix" required>
    <input type="file" name="image" required>
    <input type="submit" name="submit" value="Enregistrer">
    <a href="admin.php"><button type="button">Admin</button></a>
</form>


    <h2>Modifier les informations des voitures</h2>
    
    <form method="POST">
        <label for="car_id">Sélectionnez une voiture:</label>
        <select name="car_id" id="car_id" required>
            <option value="">-- Sélectionnez une voiture --</option>
            <?php foreach ($cars as $car): ?>
                <option value="<?= $car['id']; ?>"><?= htmlspecialchars($car['voiture_name']); ?></option>
            <?php endforeach; ?>
        </select>
        <br>

        <label for="image_path">Chemin de l'image:</label>
        <input type="text" name="image_path" id="image_path" required>
        <br>

        <label for="voiture_name">Nom de la voiture:</label>
        <input type="text" name="voiture_name" id="voiture_name" required>
        <br>

        <label for="prix">Prix:</label>
        <input type="number" name="prix" id="prix" required>
        <br>

        <input type="submit" name="update" value="Mettre à jour">
    </form>
    
    <h3>Supprimer une voiture</h3>
    <form method="POST">
        <label for="car_id">Sélectionnez une voiture à supprimer:</label>
        <select name="car_id" id="car_id" required>
            <option value="">-- Sélectionnez une voiture --</option>
            <?php foreach ($cars as $car): ?>
                <option value="<?= $car['id']; ?>"><?= htmlspecialchars($car['voiture_name']); ?></option>
            <?php endforeach; ?>
        </select>
        <br>
        <input type="submit" name="delete" value="Supprimer la voiture">
    </form>

    <h4>Liste des Voitures</h4>
<table border="1">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nom de la Voiture</th>
            <th>Prix</th>
            <th>Image</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($cars as $car): ?>
            <tr>
                <td><?= htmlspecialchars($car['id']); ?></td>
                <td><?= htmlspecialchars($car['voiture_name']); ?></td>
                <td><?= htmlspecialchars($car['Prix']); ?></td>
                <td>
                    <img src="<?= htmlspecialchars($car['image_path']); ?>" alt="<?= htmlspecialchars($car['voiture_name']); ?>" style="width: 100px; height: auto;">
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</body>
</html>