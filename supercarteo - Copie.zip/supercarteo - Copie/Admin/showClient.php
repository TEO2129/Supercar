<?php
session_start();
$bdd = new PDO('mysql:host=localhost;dbname=abaidine_supercar;charset=utf8', 'root', '');

if (isset($_POST['submit'])) {
    if (!empty($_POST['nom']) && !empty($_POST['prenom']) && !empty($_POST['email']) && !empty($_POST['identifiant']) && !empty($_POST['password']) && !empty($_POST['adresse']) && !empty($_POST['tel'])) {
        
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $email = $_POST['email'];
        $identifiant = $_POST['identifiant'];
        $password = $_POST['password'];
        $adresse = $_POST['adresse'];
        $tel = $_POST['tel'];

        // Prepare the SQL statement with the new fields
        $insertUser  = $bdd->prepare('INSERT INTO client(nom, prenom, email, identifiant, password, adresse, tel) VALUES(:nom, :prenom, :email, :identifiant, :password, :adresse, :tel)');
        
        // Execute the statement with the new parameters
        $insertUser ->execute(array(
            ':nom' => $nom,
            ':prenom' => $prenom,
            ':email' => $email,
            ':identifiant' => $identifiant,
            ':password' => $password,
            ':adresse' => $adresse,
            ':tel' => $tel
        ));
        
        // Confirm that the data has been saved
        echo "Le client a été ajouté";
    } else {
        echo "Fail, veuillez réessayer";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name http-equiv="X-UA-Compatible" content="IE=edge"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <h1>Listes des utilisateurs</h1>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<main>
    <br>

<div class="link_container">
    <a class ="link" href="admin.php">Espace Admin</a>
    </div> 

   <table>
      <thead>
      <?php
            include_once "connect_ddb.php";
            //liste des utilisateurs
            $sql= "SELECT * FROM client";
            $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result)>0){
                //afficher les utilisateurs
            ?>
        <tr>
        <th>login</th>
        <th>email</th>
        <th>Supprimer</th>
     </tr>
    </thead>  
    </tbody>

    <?php
    while($row= mysqli_fetch_assoc($result)){
	?>
				<tr>
                    <td><?=$row['login']?></td>
                    <td><?=$row['email']?></td>
					<td class="image"><a href="deleteUser.php?id=<?php echo $row["Id_client"]?>"><img src="remove.png" alt=""></a></td>
                </tr>
           
                <?php
                }
            }
            else{
                echo " <p class='message'>0 utilisateur présent !</p>";
            }
              ?>
            </tbody>
        </table>
    </main>

<br>
    <form action="" method="post">
        <h2>Ajouter un utilisateur</h2>
          <input type="text" name="login" placeholder="login">
          <input type="password" name="password" placeholder="password">
		  <input type="email" name="email" placeholder="email">
          <input type="submit" value="Ajouter" name="submit">
    </form>  

   
</body>
</html>