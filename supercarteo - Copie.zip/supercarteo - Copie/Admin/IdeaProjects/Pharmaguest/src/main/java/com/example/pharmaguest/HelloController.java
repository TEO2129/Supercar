package com.example.pharmaguest;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class HelloController {
    public ScrollPane statusScrollPane;
    public Button connectButton;
    public PasswordField passwordField;
    public TextField usernameField;
    public RadioButton studentRadioButton;
    public RadioButton teacherRadioButton;
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    public void onConnectButtonClick() {
    }
}