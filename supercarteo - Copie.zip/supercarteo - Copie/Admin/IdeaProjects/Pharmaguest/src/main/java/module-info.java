module com.example.pharmaguest {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.pharmaguest to javafx.fxml;
    exports com.example.pharmaguest;
}