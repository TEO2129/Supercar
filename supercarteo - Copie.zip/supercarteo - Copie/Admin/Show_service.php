<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>

<main>

    <table>
        <thead>
        <a class="link back"  href="admin.php"> Admin</a>
<br>
</br>
        <?php
        include_once "connect_ddb.php";
        //liste des utilisateurs
        $sql= "SELECT ID_Service, ID_Voiture FROM service";
        $result = $conn->query($sql);
        if ($result->num_rows > 0){
            //afficher les utilisateurs
       ?>
            <tr>
                <th>commentaire</th>
            </tr>
        </thead>
        <tbody>
        <?php
            while($row = $result->fetch_assoc()){

       ?>    
            <tr>
                <td><?php echo $row["commentaire"];?></td>
            </tr>

            <?php
            }
        }
        else{
            echo " <p class='message'>Aucun </p>";
        }
           ?>
        </tbody>
    </table>
</main>

</body>
</html>