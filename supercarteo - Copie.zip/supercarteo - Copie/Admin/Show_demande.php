<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>demande_essai</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>

<main>

    <table>
        <thead>
        <a class="link back"  href="admin.php"> Admin</a>
<br>
</br>
        <?php
        include_once "connect_ddb.php";
        //liste des utilisateurs
        $sql= "SELECT nom, Date,	Nom_Voiture	 FROM voiture";
        $result = $conn->query($sql);
        if ($result->num_rows > 0){
            //afficher les utilisateurs
       ?>
            <tr>
                <th>Nom</th>
                <th>Date</th>
                <th>Nom_voiture</th>
            </tr>
        </thead>
        <tbody>
        <?php
            while($row = $result->fetch_assoc()){

       ?>    
            <tr>
                <td><?php echo $row["nom"];?></td>
                <td><?php echo $row["date"];?></td>
                <td><?php echo $row["Nom_voiture"];?></td>
            </tr>

            <?php
            }
        }
        else{
            echo " <p class='message'>Aucune demande d'essai </p>";
        }
           ?>
        </tbody>
    </table>
</main>

</body>
</html>