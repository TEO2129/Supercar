<?php
session_start();
$bdd = new PDO('mysql:host=localhost;dbname=abaidine_supercar;charset=utf8', 'root', '');
if (isset($_POST['submit'])) {
	if (!empty($_POST['login']) &&!empty($_POST['email']) &&!empty($_POST['password'])){
			$login = $_POST['login'];
			$email = $_POST['email'];
			$password = $_POST['password'];
			$insertUser = $bdd->prepare('INSERT INTO admin(login, email, password) VALUES(:login, :email, :password)');
			$insertUser->execute(array(':login' => $login, ':email' => $email, ':password' => $password));
			
			// Confirm that the data has been saved
			echo "L'utilisateur a été ajouté";
			
			
	}
	else {
		echo "Fail, veuillez réessayer";
	}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name http-equiv="X-UA-Compatible" content="IE=edge"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <h1>Listes des utilisateurs</h1>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<main>
    <br>

<div class="link_container">
    <a class ="link" href="admin.php">Espace Admin</a>
    </div> 

   <table>
      <thead>
      <?php
            include_once "connect_ddb.php";
            //liste des utilisateurs
            $sql= "SELECT * FROM admin";
            $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result)>0){
                //afficher les utilisateurs
            ?>
        <tr>
        <th>login</th>
        <th>email</th>
        <th>Supprimer</th>
     </tr>
    </thead>  
    </tbody>

    <?php
    while($row= mysqli_fetch_assoc($result)){
	?>
				<tr>
                    <td><?=$row['login']?></td>
                    <td><?=$row['email']?></td>
					<td class="image"><a href="deleteUser.php?id=<?php echo $row["Id_Admin"]?>"><img src="remove.png" alt=""></a></td>
                </tr>
           
                <?php
                }
            }
            else{
                echo " <p class='message'>0 utilisateur présent !</p>";
            }
              ?>
            </tbody>
        </table>
    </main>

<br>
    <form action="" method="post">
        <h2>Ajouter un utilisateur</h2>
          <input type="text" name="login" placeholder="login">
          <input type="password" name="password" placeholder="password">
		  <input type="email" name="email" placeholder="email">
          <input type="submit" value="Ajouter" name="submit">
    </form>  

   
</body>
</html>