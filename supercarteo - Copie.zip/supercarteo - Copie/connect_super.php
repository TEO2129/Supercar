<?php
$host = "localhost"; // Correctly define the host
$dbname = "abaidine_supercar"; // Ensure this is the correct database name
$username = "root"; // Your database username
$password = ""; // Your database password

try {
    // Create a new PDO instance
    $bdd = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    
    // Set the PDO error mode to exception
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Optional: You can echo a success message if needed
    // echo "Connection successful!";
} catch (PDOException $e) {
    // Handle connection error
    echo 'Connection failed: ' . $e->getMessage();
}
?>